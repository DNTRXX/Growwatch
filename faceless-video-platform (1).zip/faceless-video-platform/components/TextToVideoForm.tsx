import { useState } from 'react';

export default function TextToVideoForm() {
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [videoUrl, setVideoUrl] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Mock: simulate API call
    setTimeout(() => {
      setVideoUrl('https://via.placeholder.com/480x270?text=Video+Preview');
      setLoading(false);
    }, 2000);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded shadow">
      <textarea
        className="w-full border border-gray-300 p-2 rounded mb-4 h-32"
        placeholder="Gib deinen Text hier ein..."
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <button
        type="submit"
        className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 disabled:opacity-50"
        disabled={!text || loading}
      >
        {loading ? 'Erzeuge Video...' : 'Video erzeugen'}
      </button>
      {videoUrl && (
        <div className="mt-4">
          <h2 className="font-semibold mb-2">Vorschau:</h2>
          <img src={videoUrl} alt="Video Preview" className="w-full rounded" />
        </div>
      )}
    </form>
  );
}