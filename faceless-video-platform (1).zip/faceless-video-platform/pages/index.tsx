import Head from 'next/head';
import TextToVideoForm from '../components/TextToVideoForm';

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
      <Head>
        <title>Faceless Video Platform</title>
      </Head>
      <h1 className="text-3xl font-bold mb-4">Faceless Video Generator</h1>
      <div className="w-full max-w-xl">
        <TextToVideoForm />
      </div>
    </div>
  );
}