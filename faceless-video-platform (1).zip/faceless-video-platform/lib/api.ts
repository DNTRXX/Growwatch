export async function generateVideoFromText(text: string): Promise<string> {
  // Hier API-Aufrufe zu OpenAI und D-ID einfügen
  return 'https://via.placeholder.com/480x270?text=Video+Preview';
}