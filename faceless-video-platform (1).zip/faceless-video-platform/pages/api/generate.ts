import type { NextApiRequest, NextApiResponse } from 'next';

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  // Hier würde die Logik für OpenAI/D-ID Anbindung stehen
  res.status(200).json({ message: 'API-Route noch nicht implementiert' });
}